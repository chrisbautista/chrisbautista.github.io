HOW TO USE RTC-SCM
===============

## Roadmap
-------
> see rtc-scm.xlsx for pending items
* better password encryption


## Files/Folders
-------------

rtc-scm.cmd => call rtc-scm.js as a single cli command e.g.  rtc-scm arg1 arg2
rtc.bat  => alias to lscm, invoke rtc without modifying the path

rtc-scm.js => test file, 

```
 node rtc-scm.js
```

node_modules/rtc-scm/* => rtc-scm module 
team_concert.json => config file


How to Setup
============

1) Copy rtc-scm into your project. RECOMMENDED: under node_modules
2) Copy rtc.bat to root of your project. Update location of rtc commandline scripts. 
   SET PRGPATH=C:\swdtools\IBM\RTC4\scmtools\eclipse\
3) Setup configuration file(see team_concert.json.sample)

4) Consume as node module
   
   var rscm = require("rtc-scm");
   var config = require("config.json");

   config = {


   };

``` Javascript

   var rscm = require("rtc-scm");
   var config = require("config.json");
   var session = new rscm(config);

   session.ListProjectAreas( function(res){ console.log(">>> output \n", res); });

``` 

   or


``` Javascript

   var rscm = require("rtc-scm");
   var config = require("config.json");
   var session = new rscm();


   function listHandler(res){
	  console.log(">>> output \n", res);
   }

   session.ListProjectAreas( 

   		listHandler,

   		config);


```


Config JSON file
==================
You can save config gile anywhere in your filesystem as long as you can look


```javasript

{  
   "user": "USER-HERE",
   "password": "PASSWORD-HERE",


   "url": "https://jtsrv.uk.hibm.hsbc:9094/jazz/",
   "projectarea" : "_pxxt0OjPEeS8Q61MzygUCg",
   "streams" : "_LEFSUfjyEeSD5ZzgLxaY8A",
   "workspace": "_LEFSUfjyEeSD5ZzgLxaY8A",
   "saveTo" : "ws",
   "component": "sprintx-reveng",


   "output": "json",
   "verbose" : "true",
   "showcommands" : "true",
   "progress" : "false"
}

```