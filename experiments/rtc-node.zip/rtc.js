#!/usr/bin/env node

/** load rtc-scm  **/
var rscm = require('rtc-scm');

/**
 * load config 
 * type  JSON
 */
var config = require('./team_concert.json');


/**
 * setup rtc session
 */
config.perTick = 1000;

var session = new rscm(config);

//var session = new rscm();


//
// PLUGIN MODE
//
/*
config =  {	
	"user": "43904801",
	"password": "NOTMYPASSWORD",
	"url": "https://jtsrv.uk.hibm.hsbc:9094/jazz/",
	"projectarea" : "_pxxt0OjPEeS8Q61MzygUCg",
	"streams" : "_LEFSUfjyEeSD5ZzgLxaY8A",
	"workspace": "_LEFSUfjyEeSD5ZzgLxaY8A",
	"saveTo" : "ws",
	"component": "sprintx-reveng",
	"output": "json",
	"verbose" : "true",
	"show_commands" : "true"
}
*/



//session.ListProjectAreas( function(res){ console.log(">>> output \n", res); });
//session.ListProjectAreas( function(res){ console.log(">>> output \n", res); }, config );
//session.ListStreams(function(res){ console.log(">>> output \n", res); });
//session.ListWorkspaces(function(res){ console.log(">>> output \n", res); });
/*
session.GetStatus(function(res){ console.log("\n>>> output \n", res);
	session.Clone(function(res){ console.log("\n>>> output", res); });
});

 */
session.Clone(function(res){ console.log("\n >>> output", res); });

//session.AddChanges(function(res){ console.log(">>> output \n", res); });
//session.CommitPush(changeSet, message, function(res){ console.log(">>> output \n", res);  });

// simulataneously();
// successively();

/**  Sample

// pull from RTC
session.Clone(function(){
	
	//successful! Proceed with build
	runBuild();
	runTests();
	deploy();

})

 */



/**
 * Run simulataneously
 * @return {[type]} [description]
 */
function simultaneous(){

	session.ListProjectAreas( function(res){ console.log(">>> output \n", res); });
	
	session.ListStreams(function(res){ console.log(">>> output \n", res); });
}


/**
 * Run successively
 */

function successively(){

	session.ListProjectAreas( function(res){ 
		console.log(">>> output \n", res);

		if(res.status === "OK") {
	
			session.ListStreams(function(res){ 
				console.log(">>> output \n", res); 
				session.ListWorkspaces(function(res){ 
					console.log(">>> output \n", res); 
				});
			});

		}

	});
	
}
